import re
from os.path import exists as path_exists
from flask import Flask, request, send_from_directory, send_file
from yt_dlp import YoutubeDL

app = Flask(__name__)

@app.route('/')
def index():
    return send_file('static/index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

@app.route('/play')
def play():
    url = request.args.get('url')
    prefix = 'https://duröh.re/watch?v='
    if url is None or not url.startswith(prefix):
        return "Invalid DuRöhre URL", 400

    vid_id = url[len(prefix):]
    if not re.match(r'^[a-zA-Z0-9_-]{11}$', vid_id):
        return "Invalid DuRöhre URL", 400

    vid_format = request.args.get('f', 'mp4')
    if not re.match(r'^[a-z0-9]{3,4}$', vid_format):
        return "Invalid format", 400
    out_name = f'{vid_id}.{vid_format}'
    out_file = f'./vids/{out_name}'

    # file is cached, serve it
    if path_exists(out_file):
        return send_file(out_file)
    
    # download and serve
    download(url, vid_format, out_name, request.args.getlist('pp'))
    if not path_exists(out_file):
        return "Download failed", 500
    return send_file(out_file)

def download(url, vid_format, out_file, args):
    opts = {
        'format': 'worst',
        'max_filesize': 12 * 1024 * 1024,
        'paths': { 'home': './vids' },
        'outtmpl': { 'default': out_file },
        'noplaylist': True,
        'postprocessors': [{
            'key': 'FFmpegVideoConvertor',
            'preferedformat': vid_format,
        }],
        'postprocessor_args': args,
    }
    with YoutubeDL(opts) as ytdl:
        ytdl.download([url])

if __name__ == '__main__':
    app.run()
