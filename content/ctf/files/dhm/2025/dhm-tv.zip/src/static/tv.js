function setTitle(title) {
    document.getElementById('display-contents').textContent = title;
}

const root = document.querySelector(':root');
const screen = document.getElementById('screen');
const video = document.getElementById('video');
const power = document.getElementById('power');
const mute = document.getElementById('mute');

power.onclick = () => {
    if (root.dataset.power === 'on') {
        root.dataset.power = 'off';
    } else {
        root.dataset.power = 'on';
        turnOn();
    }
};
mute.onclick = () => {
    if (video.muted) {
        video.muted = false;
    } else {
        video.muted = true;
    }
};

const url = 'https://duröh.re/watch?v=PVhYhLQ4Y64';
const title = 'Kuchenblech';

root.dataset.power = 'on';
setTitle('Loading...');
const src = document.createElement('source');
src.src = `/play?url=${url}`;
src.type = 'video/mp4';
video.appendChild(src);
video.oncanplay = () => {
    screen.dataset.playing = 'true';
    setTitle(title);
    video.oncanplay = null;
};
